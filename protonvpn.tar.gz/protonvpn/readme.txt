/etc/protonvpn - рабочая папка
/etc/protonvpn/*.ovpn - файлы конфигураций из скаченного ProtonVPN_server_configs.zip
/etc/protonvpn/protonvpn.pass - файл с паролями
/etc/protonvpn/update-resolv-conf - скрипт подстановки DNS из VPN в /etc/resolv.conf
/etc/protonvpn/protonvpn.xml - файл конфигурации GUI
/etc/systemd/system/protonvpn.service - сервис запуска через systemd
/usr/bin/protonvpn - пускач через pkexec
/usr/share/applications/protonvpn.desktop - ярлык запуска основного меню
/usr/share/polkit-1/actions/protonvpn.policy - политика запуска через pkexec
/usr/share/protonvpn - GUI (Lazarus source + bin)
/usr/share/icons/protonvpn.png - иконка в основном меню
/usr/share/doc/protonvpn/repack.txt - инфо
/run/openvpn/protonvpn.pid - индентификатор процесса
/var/log/protonvpn.log - лог подключения


